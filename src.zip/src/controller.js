angular.module('starter.controllers', [])
  .controller('ToDoListCtrl', function ($scope) {
    $scope.toDoListItems = [{
      task: 'Sky Diving',
      status: 'not done'
    }, {
      task: 'Climb Fuji',
      status: 'not done'
      }]
  });// JavaScript source code
